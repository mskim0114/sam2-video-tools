#!/usr/bin/env python3
"""
SAM2 Video Composition Pipeline
────────────────────────────────────────────────────────────
SAM2로 세그멘테이션한 객체를 다른 배경 영상에 합성하는 도구

사용법:
python sam2_video_compose.py --bg 배경영상.mp4 --obj 원본영상.mp4 --mask output_masks/ --out 합성결과.mp4
"""

import cv2, numpy as np, argparse, time, sys, os
from pathlib import Path
from PIL import Image

# ────────────── CLI ──────────────────────────────────────────────
ap = argparse.ArgumentParser()
ap.add_argument('--bg',  required=True, help='배경 영상 경로')
ap.add_argument('--obj', required=True, help='오브젝트 영상 경로 (원본)')
ap.add_argument('--mask', required=True, help='SAM2 마스크 폴더 경로')
ap.add_argument('--out', default='composed_result.mp4', help='출력 파일명')
ap.add_argument('--size', type=int, default=200, help='오브젝트 최장변(px)')
ap.add_argument('--pos', default='center', choices=['center', 'top-left', 'top-right', 'bottom-left', 'bottom-right'], help='합성 위치')
ap.add_argument('--offset-x', type=int, default=0, help='X축 오프셋')
ap.add_argument('--offset-y', type=int, default=0, help='Y축 오프셋')
ap.add_argument('--blend-mode', default='normal', choices=['normal', 'multiply', 'screen', 'overlay'], help='블렌딩 모드')
ap.add_argument('--brightness-match', action='store_true', help='밝기 자동 맞춤')
ap.add_argument('--preview', action='store_true', help='미리보기 모드')
ap.add_argument('--loop', action='store_true', help='영상 반복 재생')
args = ap.parse_args()

# ────────────── 비디오 열기 ─────────────────────────────────────
cap_bg = cv2.VideoCapture(args.bg)
cap_obj = cv2.VideoCapture(args.obj)

if not cap_bg.isOpened():
    raise RuntimeError(f"⛔ 배경 영상을 열 수 없습니다: {args.bg}")
if not cap_obj.isOpened():
    raise RuntimeError(f"⛔ 오브젝트 영상을 열 수 없습니다: {args.obj}")

# 비디오 정보
fps_bg = cap_bg.get(cv2.CAP_PROP_FPS)
W_bg = int(cap_bg.get(cv2.CAP_PROP_FRAME_WIDTH))
H_bg = int(cap_bg.get(cv2.CAP_PROP_FRAME_HEIGHT))

fps_obj = cap_obj.get(cv2.CAP_PROP_FPS)
W_obj = int(cap_obj.get(cv2.CAP_PROP_FRAME_WIDTH))
H_obj = int(cap_obj.get(cv2.CAP_PROP_FRAME_HEIGHT))

print(f"배경: {W_bg}x{H_bg} @ {fps_bg}fps")
print(f"오브젝트: {W_obj}x{H_obj} @ {fps_obj}fps")

# ────────────── 마스크 파일 목록 ──────────────────────────────────
mask_files = sorted([f for f in os.listdir(args.mask) if f.endswith('.png')])
if not mask_files:
    raise RuntimeError(f"⛔ 마스크 파일을 찾을 수 없습니다: {args.mask}")

print(f"마스크 파일 수: {len(mask_files)}")

# ────────────── 위치 계산 함수 ───────────────────────────────────
def calculate_position(bg_size, obj_size, position, offset_x=0, offset_y=0):
    """합성 위치 계산"""
    bg_w, bg_h = bg_size
    obj_w, obj_h = obj_size
    
    if position == 'center':
        x = (bg_w - obj_w) // 2 + offset_x
        y = (bg_h - obj_h) // 2 + offset_y
    elif position == 'top-left':
        x = offset_x
        y = offset_y
    elif position == 'top-right':
        x = bg_w - obj_w + offset_x
        y = offset_y
    elif position == 'bottom-left':
        x = offset_x
        y = bg_h - obj_h + offset_y
    elif position == 'bottom-right':
        x = bg_w - obj_w + offset_x
        y = bg_h - obj_h + offset_y
    
    return max(0, x), max(0, y)

# ────────────── 블렌딩 함수들 ────────────────────────────────────
def blend_normal(fg, bg, alpha):
    """일반 블렌딩"""
    return fg * alpha + bg * (1 - alpha)

def blend_multiply(fg, bg, alpha):
    """곱셈 블렌딩"""
    blended = fg * bg
    return blended * alpha + bg * (1 - alpha)

def blend_screen(fg, bg, alpha):
    """스크린 블렌딩"""
    blended = 1 - (1 - fg) * (1 - bg)
    return blended * alpha + bg * (1 - alpha)

def blend_overlay(fg, bg, alpha):
    """오버레이 블렌딩"""
    blended = np.where(bg < 0.5, 2 * fg * bg, 1 - 2 * (1 - fg) * (1 - bg))
    return blended * alpha + bg * (1 - alpha)

# 블렌딩 모드 매핑
blend_functions = {
    'normal': blend_normal,
    'multiply': blend_multiply,
    'screen': blend_screen,
    'overlay': blend_overlay
}

# ────────────── 밝기 맞춤 함수 ────────────────────────────────────
def adjust_brightness(obj_rgb, bg_bgr):
    """밝기 자동 맞춤"""
    if not args.brightness_match:
        return obj_rgb
    
    # YCrCb 변환하여 밝기 계산
    meanY_bg = np.mean(cv2.cvtColor(bg_bgr, cv2.COLOR_BGR2YCrCb)[...,0]) / 255.
    obj_bgr = cv2.cvtColor((obj_rgb * 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
    meanY_obj = np.mean(cv2.cvtColor(obj_bgr, cv2.COLOR_BGR2YCrCb)[...,0]) / 255.
    
    # 밝기 조정
    obj_adjusted = obj_rgb * (meanY_bg / (meanY_obj + 1e-3))
    obj_adjusted = np.clip(obj_adjusted, 0, 1) ** 0.9  # 감마 보정
    
    return obj_adjusted

# ────────────── 비디오 작성기 초기화 ──────────────────────────────
if not args.preview:
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    writer = cv2.VideoWriter(args.out, fourcc, fps_bg, (W_bg, H_bg))
    print(f"출력 파일: {args.out}")

# ────────────── 메인 루프 ─────────────────────────────────────────
print("합성 시작... (Q: 종료, S: 저장)")
t0, fc = time.time(), 0

while True:
    ret_bg, bg_bgr = cap_bg.read()
    ret_obj, obj_bgr = cap_obj.read()
    
    # 영상이 끝났을 때 처리
    if not ret_bg or not ret_obj:
        if args.loop:
            # 반복 모드: 처음부터 다시 시작
            cap_bg.set(cv2.CAP_PROP_POS_FRAMES, 0)
            cap_obj.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ret_bg, bg_bgr = cap_bg.read()
            ret_obj, obj_bgr = cap_obj.read()
            if not (ret_bg and ret_obj):
                print("영상 재시작 실패")
                break
            print("영상이 끝났습니다. 처음부터 다시 시작합니다.")
        else:
            # 일반 모드: 종료
            print("영상이 끝났습니다.")
            break
    
    # 현재 프레임에 해당하는 마스크 로드
    frame_idx = min(fc, len(mask_files) - 1)  # 마스크 파일 수를 초과하지 않도록
    mask_path = os.path.join(args.mask, mask_files[frame_idx])
    
    if not os.path.exists(mask_path):
        print(f"⚠️ 마스크 파일 없음: {mask_path}")
        continue
    
    # 마스크 로드 및 전처리
    mask = np.array(Image.open(mask_path).convert('L'))
    mask = mask.astype(np.float32) / 255.0
    
    # RGB 변환
    bg_rgb = cv2.cvtColor(bg_bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.
    obj_rgb = cv2.cvtColor(obj_bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.
    
    # ── (1) 오브젝트 리사이즈
    scale = args.size / max(obj_rgb.shape[:2])
    if scale < 1.0:
        obj_rgb = cv2.resize(obj_rgb, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        mask = cv2.resize(mask, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    
    obj_h, obj_w = obj_rgb.shape[:2]
    
    # ── (2) 마스크 후처리
    mask = (mask - mask.min()) / (mask.max() - mask.min() + 1e-6)
    alpha = (mask > 0.35).astype(np.float32)
    alpha = cv2.GaussianBlur(alpha, (11, 11), 0)[..., None]
    
    # ── (3) 밝기 맞춤
    obj_rgb = adjust_brightness(obj_rgb, bg_bgr)
    
    # ── (4) 위치 계산
    x0, y0 = calculate_position((W_bg, H_bg), (obj_w, obj_h), args.pos, args.offset_x, args.offset_y)
    
    # ── (5) 합성
    blend_func = blend_functions[args.blend_mode]
    
    # ROI 추출
    roi = bg_rgb[y0:y0+obj_h, x0:x0+obj_w]
    if roi.shape[:2] == (obj_h, obj_w):
        # 블렌딩
        blended = blend_func(obj_rgb, roi, alpha)
        bg_rgb[y0:y0+obj_h, x0:x0+obj_w] = blended
    
    # ── (6) 출력
    out_bgr = cv2.cvtColor((bg_rgb * 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
    
    # 정보 표시
    info_text = f"Frame: {fc} | Mask: {mask_files[frame_idx]} | Pos: ({x0},{y0})"
    cv2.putText(out_bgr, info_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    if args.brightness_match:
        meanY = np.mean(cv2.cvtColor(bg_bgr, cv2.COLOR_BGR2YCrCb)[...,0])
        cv2.putText(out_bgr, f'Y: {meanY:.0f}', (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    # 저장 및 표시
    if not args.preview:
        writer.write(out_bgr)
    
    cv2.imshow('SAM2 Video Composition', out_bgr)
    
    # 키 입력 처리
    key = cv2.waitKey(1) & 0xFF
    if key in (ord('q'), ord('Q')):
        break
    elif key == ord('s'):
        # 현재 프레임 저장
        cv2.imwrite(f'compose_frame_{fc:05d}.png', out_bgr)
        print(f"프레임 저장: compose_frame_{fc:05d}.png")
    
    fc += 1
    if fc % 30 == 0:
        now = time.time()
        time_spent = now - t0
        print(f'fps≈{30/time_spent:.1f} | Frame: {fc} | Mask: {mask_files[frame_idx]}')
        t0 = now

# ────────────── 정리 ──────────────────────────────────────────────
cap_bg.release()
cap_obj.release()
if not args.preview:
    writer.release()
cv2.destroyAllWindows()

print(f'완료! 총 {fc} 프레임 처리')
if not args.preview:
    print(f'출력 파일: {args.out}') 