import os
import cv2
import numpy as np
from PIL import Image

def render_masks_to_video(frame_dir, mask_dir, output_video, fps=30):
    frame_files = sorted([f for f in os.listdir(frame_dir) if f.lower().endswith('.jpg')])
    mask_files = sorted([f for f in os.listdir(mask_dir) if f.endswith('.png')])

    if not frame_files or not mask_files:
        print("No frames or masks found!")
        return

    sample_frame = cv2.imread(os.path.join(frame_dir, frame_files[0]))
    height, width = sample_frame.shape[:2]
    writer = cv2.VideoWriter(output_video, cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))
    for f_name, m_name in zip(frame_files, mask_files):
        frame = cv2.imread(os.path.join(frame_dir, f_name))
        mask = np.array(Image.open(os.path.join(mask_dir, m_name)).convert("L"))
        mask_rgb = np.zeros_like(frame)
        mask_rgb[mask > 128] = [0, 255, 0]
        blended = cv2.addWeighted(frame, 0.7, mask_rgb, 0.3, 0)
        writer.write(blended)
    writer.release()
    print(f"Rendered video saved to: {output_video}")
