import os
import numpy as np
from PIL import Image
import torch
import cv2

# 반드시 sam2 설치 및 환경 세팅 필요!
from sam2.build_sam import build_sam2_video_predictor

def run_segmentation(frame_dir, mask_dir, sam2_checkpoint, model_cfg, device=None):
    os.makedirs(mask_dir, exist_ok=True)
    frame_files = sorted([f for f in os.listdir(frame_dir) if f.lower().endswith('.jpg')])

    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    predictor = build_sam2_video_predictor(model_cfg, sam2_checkpoint, device=device)

    # 배치 크기 설정 (메모리 절약)
    batch_size = 100  # 한 번에 처리할 프레임 수
    
    for batch_start in range(0, len(frame_files), batch_size):
        batch_end = min(batch_start + batch_size, len(frame_files))
        batch_files = frame_files[batch_start:batch_end]
        
        print(f"Processing batch {batch_start//batch_size + 1}/{(len(frame_files) + batch_size - 1)//batch_size}")
        
        # 배치용 임시 비디오 생성
        temp_video_path = f"temp_frames_batch_{batch_start}.mp4"
        
        # 첫 번째 프레임으로 비디오 크기 확인
        first_frame = cv2.imread(os.path.join(frame_dir, batch_files[0]))
        height, width = first_frame.shape[:2]
        
        # 배치 프레임들을 비디오로 변환
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(temp_video_path, fourcc, 30.0, (width, height))
        
        for fname in batch_files:
            frame = cv2.imread(os.path.join(frame_dir, fname))
            out.write(frame)
        out.release()
        
        try:
            # SAM2 상태 초기화
            state = predictor.init_state(
                video_path=temp_video_path,
                offload_video_to_cpu=True
            )
            predictor.reset_state(state)
            
            # 배치 내 각 프레임에 대해 자동 마스크 생성
            for idx, fname in enumerate(batch_files):
                global_idx = batch_start + idx
                
                # 프레임 중앙에 포인트 하나 추가 (자동 세그멘테이션)
                center_x, center_y = width // 2, height // 2
                points = np.array([[center_x, center_y]], dtype=np.float32)
                labels = np.array([1], dtype=np.int32)  # foreground point
                
                # SAM2 예측 실행
                _, _, logits = predictor.add_new_points_or_box(
                    inference_state=state,
                    frame_idx=idx,  # 배치 내 인덱스
                    obj_id=1,
                    points=points,
                    labels=labels,
                    box=None
                )
                
                # logits를 마스크로 변환 (logits > 0)
                mask_pred = (logits[0] > 0).cpu().numpy().astype(np.float32)
                
                # 마스크 형태 확인 및 수정
                print(f"Mask shape: {mask_pred.shape}, dtype: {mask_pred.dtype}")
                
                # 마스크가 3차원이면 2차원으로 변환
                if mask_pred.ndim == 3:
                    if mask_pred.shape[0] == 1:
                        mask_pred = mask_pred[0]  # (1, H, W) -> (H, W)
                    else:
                        mask_pred = mask_pred.squeeze()  # 불필요한 차원 제거
                
                # 마스크를 이미지로 저장
                mask_img = (mask_pred * 255).astype(np.uint8)
                Image.fromarray(mask_img).save(os.path.join(mask_dir, f"mask_{global_idx:05d}.png"))
                print(f"{fname} → mask_{global_idx:05d}.png")
                
        except Exception as e:
            print(f"Error processing batch {batch_start//batch_size + 1}: {e}")
        finally:
            # 임시 비디오 파일 삭제
            if os.path.exists(temp_video_path):
                os.remove(temp_video_path)
