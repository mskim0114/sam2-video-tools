# SAM2 Interactive Video Segmentation

SAM2를 사용한 인터랙티브 비디오 세그멘테이션 도구입니다.

## 파일 설명

### 1. `interactive_pipeline.py` (기본 버전)
- 첫 번째 프레임에서만 포인트 입력
- 전체 비디오에 자동 전파
- 간단한 사용법

### 2. `advanced_interactive.py` (고급 버전)
- 여러 프레임에서 포인트 입력 가능
- 프레임 간 이동 및 멀티 오브젝트 지원
- 상태 저장/불러오기 기능
- 메모리 최적화된 배치 처리

## 사용법

### 기본 버전 (interactive_pipeline.py)
```bash
cd /home/keti/sam2
python my_own/interactive_pipeline.py
```

### 고급 버전 (advanced_interactive.py)
```bash
cd /home/keti/sam2
python my_own/advanced_interactive.py --video 도로주행2.mp4
```

#### 고급 버전 옵션
```bash
python my_own/advanced_interactive.py \
    --video 도로주행2.mp4 \
    --frame-dir tmp_frames \
    --mask-dir output_masks \
    --output segmentation_result.mp4 \
    --checkpoint checkpoints/sam2.1_hiera_tiny.pt \
    --config configs/sam2.1/sam2.1_hiera_t.yaml \
    --fps 30 \
    --batch-size 100
```

## 컨트롤

### 마우스
- **좌클릭**: 포그라운드 포인트 (녹색)
- **우클릭**: 백그라운드 포인트 (빨간색)

### 키보드
- **ENTER**: 현재 포인트로 세그멘테이션 실행 및 전체 비디오 전파
- **←/→**: 이전/다음 프레임으로 이동 (고급 버전만)
- **n/N**: 새로운 오브젝트 ID 시작 (고급 버전만)
- **r/R**: 현재 프레임의 포인트 초기화
- **s/S**: 현재 상태 저장 (고급 버전만)
- **l/L**: 저장된 상태 불러오기 (고급 버전만)
- **q/ESC**: 종료

## 사용 시나리오

### 시나리오 1: 단순한 객체 세그멘테이션
1. `interactive_pipeline.py` 실행
2. 첫 번째 프레임에서 객체 주변 클릭
3. ENTER 키로 세그멘테이션 실행
4. 결과 확인

### 시나리오 2: 복잡한 다중 객체 세그멘테이션
1. `advanced_interactive.py --video 영상파일.mp4` 실행
2. 첫 번째 프레임에서 첫 번째 객체 클릭
3. ENTER로 세그멘테이션 실행
4. 'n' 키로 새 오브젝트 시작
5. 다른 객체 클릭 후 ENTER
6. 필요시 다른 프레임으로 이동하여 추가 포인트 입력
7. 's' 키로 상태 저장

### 시나리오 3: 프레임별 세밀한 조정
1. `advanced_interactive.py` 실행
2. 첫 번째 프레임에서 포인트 입력
3. → 키로 다음 프레임으로 이동
4. 필요시 추가 포인트 입력
5. 모든 프레임 확인 후 ENTER로 실행

## 출력 파일

- `segmentation_result.mp4`: 세그멘테이션 결과 비디오
- `output_masks/`: PNG 마스크 파일들
- `interactive_state.pkl`: 상태 저장 파일 (고급 버전)

## 팁

1. **포인트 위치**: 객체의 경계선 근처에 포인트를 찍으면 더 정확한 결과를 얻을 수 있습니다
2. **포인트 수**: 너무 많은 포인트보다는 핵심적인 몇 개의 포인트가 더 좋습니다
3. **프레임 이동**: 고급 버전에서는 여러 프레임에서 포인트를 입력하여 더 정확한 세그멘테이션을 할 수 있습니다
4. **상태 저장**: 긴 작업의 경우 주기적으로 상태를 저장하세요
5. **배치 크기**: 메모리 문제가 있다면 `--batch-size`를 줄여보세요

## 문제 해결

### 메모리 부족 오류
- `--batch-size`를 50이나 30으로 줄여보세요
- 더 작은 해상도의 영상을 사용하세요

### 세그멘테이션 품질 개선
- 더 많은 포인트를 입력해보세요
- 포그라운드와 백그라운드 포인트를 균형있게 입력하세요
- 객체의 경계선 근처에 포인트를 찍어보세요

### 프레임 추출 문제
- 영상 파일 경로가 올바른지 확인하세요
- 영상 파일이 손상되지 않았는지 확인하세요 