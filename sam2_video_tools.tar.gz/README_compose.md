# SAM2 Video Composition Tool

SAM2로 세그멘테이션한 객체를 다른 배경 영상에 합성하는 도구입니다.

## 기능

- ✅ SAM2 마스크 기반 정확한 객체 추출
- ✅ 다양한 블렌딩 모드 (normal, multiply, screen, overlay)
- ✅ 자동 밝기 맞춤
- ✅ 다양한 합성 위치 설정
- ✅ 실시간 미리보기
- ✅ 프레임별 저장 기능

## 사용법

### 기본 사용법
```bash
cd /home/keti/sam2
python my_own/sam2_video_compose.py \
    --bg 배경영상.mp4 \
    --obj 원본영상.mp4 \
    --mask output_masks/ \
    --out 합성결과.mp4
```

### 고급 옵션
```bash
python my_own/sam2_video_compose.py \
    --bg 배경영상.mp4 \
    --obj 원본영상.mp4 \
    --mask output_masks/ \
    --out 합성결과.mp4 \
    --size 300 \
    --pos center \
    --offset-x 50 \
    --offset-y -30 \
    --blend-mode overlay \
    --brightness-match \
    --preview
```

## 매개변수 설명

### 필수 매개변수
- `--bg`: 배경 영상 경로
- `--obj`: 오브젝트 영상 경로 (원본)
- `--mask`: SAM2 마스크 폴더 경로

### 선택 매개변수
- `--out`: 출력 파일명 (기본값: `composed_result.mp4`)
- `--size`: 오브젝트 최장변 크기 (기본값: 200px)
- `--pos`: 합성 위치 (기본값: `bottom-right`)
  - `center`: 중앙
  - `top-left`: 좌상단
  - `top-right`: 우상단
  - `bottom-left`: 좌하단
  - `bottom-right`: 우하단
- `--offset-x`: X축 오프셋 (기본값: 0)
- `--offset-y`: Y축 오프셋 (기본값: 0)
- `--blend-mode`: 블렌딩 모드 (기본값: `normal`)
  - `normal`: 일반 블렌딩
  - `multiply`: 곱셈 블렌딩
  - `screen`: 스크린 블렌딩
  - `overlay`: 오버레이 블렌딩
- `--brightness-match`: 밝기 자동 맞춤 활성화
- `--preview`: 미리보기 모드 (저장 안함)
- `--loop`: 영상 반복 재생

## 사용 예시

### 1. 기본 합성
```bash
python my_own/sam2_video_compose.py \
    --bg 도로주행2.mp4 \
    --obj 도로주행2.mp4 \
    --mask output_masks/ \
    --out car_on_road.mp4
```

### 2. 중앙에 작은 크기로 합성
```bash
python my_own/sam2_video_compose.py \
    --bg 배경영상.mp4 \
    --obj 원본영상.mp4 \
    --mask output_masks/ \
    --out result.mp4 \
    --size 150 \
    --pos center
```

### 3. 밝기 맞춤 + 오버레이 블렌딩
```bash
python my_own/sam2_video_compose.py \
    --bg 배경영상.mp4 \
    --obj 원본영상.mp4 \
    --mask output_masks/ \
    --out result.mp4 \
    --blend-mode overlay \
    --brightness-match
```

### 4. 미리보기 모드
```bash
python my_own/sam2_video_compose.py \
    --bg 배경영상.mp4 \
    --obj 원본영상.mp4 \
    --mask output_masks/ \
    --preview
```

### 5. 반복 재생 모드
```bash
python my_own/sam2_video_compose.py \
    --bg 배경영상.mp4 \
    --obj 원본영상.mp4 \
    --mask output_masks/ \
    --out result.mp4 \
    --loop
```

## 컨트롤

실행 중 키보드 컨트롤:
- **Q**: 종료
- **S**: 현재 프레임을 PNG로 저장

## 블렌딩 모드 설명

### Normal (일반)
가장 기본적인 블렌딩. 알파 채널을 사용하여 전경과 배경을 혼합합니다.

### Multiply (곱셈)
전경과 배경을 곱하여 어두운 효과를 만듭니다. 그림자나 어두운 부분에 유용합니다.

### Screen (스크린)
곱셈의 반대 효과. 밝은 부분을 강조합니다. 빛나는 효과에 유용합니다.

### Overlay (오버레이)
배경의 밝기에 따라 곱셈과 스크린을 조합합니다. 대비를 높이는 효과가 있습니다.

## 팁

1. **마스크 품질**: SAM2 세그멘테이션 품질이 합성 결과에 직접 영향을 줍니다
2. **크기 조정**: `--size` 옵션으로 오브젝트 크기를 조정하세요
3. **위치 조정**: `--offset-x`, `--offset-y`로 미세 조정이 가능합니다
4. **밝기 맞춤**: `--brightness-match`로 자연스러운 합성을 만드세요
5. **블렌딩 모드**: 상황에 맞는 블렌딩 모드를 선택하세요

## 문제 해결

### 마스크 파일이 없을 때
- SAM2 세그멘테이션을 먼저 실행했는지 확인
- 마스크 폴더 경로가 올바른지 확인

### 성능 문제
- `--size`를 줄여서 오브젝트 크기를 줄이세요
- 더 작은 해상도의 영상을 사용하세요

### 합성 품질 개선
- 더 정확한 SAM2 세그멘테이션 수행
- 적절한 블렌딩 모드 선택
- 밝기 맞춤 옵션 사용 