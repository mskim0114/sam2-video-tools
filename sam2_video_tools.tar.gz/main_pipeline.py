from extract_frame import extract_frames
from segmentation import run_segmentation
from render_video import render_masks_to_video

# 설정값 지정
video_path = '도로주행2.mp4'
frame_dir = 'tmp_frames'
mask_dir = 'output_masks'
output_video = 'segmentation_result.mp4'
sam2_checkpoint = "checkpoints/sam2.1_hiera_tiny.pt"
model_cfg = "configs/sam2.1/sam2.1_hiera_t.yaml"
fps = 30

# 각 단계 실행
extract_frames(video_path, frame_dir)
run_segmentation(frame_dir, mask_dir, sam2_checkpoint, model_cfg)
render_masks_to_video(frame_dir, mask_dir, output_video, fps)
