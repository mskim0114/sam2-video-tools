#!/usr/bin/env python3
"""
Advanced Interactive Video Segmentation Pipeline with SAM2 (Memory Optimized)
────────────────────────────────────────────────────────────
 ▸ 좌클릭   : positive point  (foreground)
 ▸ 우클릭   : negative point  (background)
 ▸ ENTER    : 현재 프레임을 기준으로 SAM-2 실행 → 전체 비디오로 전파
 ▸ ←/→      : 이전/다음 프레임으로 이동
 ▸ n / N    : 새로운 오브젝트 ID 시작 (멀티-오브젝트 지원)
 ▸ r / R    : 현재 프레임의 포인트 초기화
 ▸ s / S    : 현재 상태 저장
 ▸ l / L    : 저장된 상태 불러오기
 ▸ q 또는 ESC: 종료
결과
 └ segmentation_result.mp4  : 최종 세그멘테이션 비디오
 └ output_masks/           : PNG 마스크 파일들
"""

import os, sys, cv2, numpy as np, torch, pickle, argparse
from pathlib import Path
from PIL import Image

# ───── 필수: sam2 설치 확인 ──────────────────────────────────────────
try:
    from sam2.build_sam import build_sam2_video_predictor
except ModuleNotFoundError:
    sys.exit("❌  sam2가 설치되어 있지 않습니다. `pip install -e sam2` 후 다시 실행하세요.")

# ───── CLI 인자 파싱 ────────────────────────────────────────────────
ap = argparse.ArgumentParser(description='Advanced Interactive Video Segmentation with SAM2')
ap.add_argument('--video', required=True, help='입력 비디오 파일 경로')
ap.add_argument('--frame-dir', default='tmp_frames', help='프레임 저장 디렉토리 (기본값: tmp_frames)')
ap.add_argument('--mask-dir', default='output_masks', help='마스크 저장 디렉토리 (기본값: output_masks)')
ap.add_argument('--output', default='segmentation_result.mp4', help='출력 비디오 파일명 (기본값: segmentation_result.mp4)')
ap.add_argument('--checkpoint', default='checkpoints/sam2.1_hiera_tiny.pt', help='SAM2 체크포인트 경로')
ap.add_argument('--config', default='configs/sam2.1/sam2.1_hiera_t.yaml', help='SAM2 설정 파일 경로')
ap.add_argument('--fps', type=int, default=30, help='출력 비디오 FPS (기본값: 30)')
ap.add_argument('--batch-size', type=int, default=100, help='배치 크기 (기본값: 100)')
args = ap.parse_args()

# ───── 설정값 ─────────────────────────────────────────────────────────
video_path = args.video
frame_dir = args.frame_dir
mask_dir = args.mask_dir
output_video = args.output
sam2_checkpoint = args.checkpoint
model_cfg = args.config
fps = args.fps
batch_size = args.batch_size

# ───── 프레임 추출 (이미 있다면 건너뛰기) ───────────────────────────
if not os.path.exists(frame_dir) or len(os.listdir(frame_dir)) == 0:
    print("프레임 추출 중...")
    from extract_frame import extract_frames
    extract_frames(video_path, frame_dir)
else:
    print("기존 프레임 사용")

# ───── 비디오 정보 로드 ─────────────────────────────────────────────
cap = cv2.VideoCapture(video_path)
assert cap.isOpened(), f'cannot open {video_path}'
total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
cap.release()
print(f'frames: {total_frames}  |  size: {W}×{H}')

# ───── SAM-2 Predictor 로드 ───────────────────────────────────────
DEV = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f'device: {DEV}  |  SAM-2 cfg: {Path(model_cfg).name}')

predictor = build_sam2_video_predictor(model_cfg, sam2_checkpoint, device=DEV)

# ───── 프레임 파일 목록 ────────────────────────────────────────────
frame_files = sorted([f for f in os.listdir(frame_dir) if f.lower().endswith('.jpg')])

# ───── 상태 변수 ───────────────────────────────────────────────────
click_pts, click_lbl = [], []           # [[x,y]], [label]
cur_obj = 1
cur_frame_idx = 0                       # 현재 프레임 인덱스
all_points = {}                         # {frame_idx: {obj_id: (points, labels)}}

# ───── 현재 프레임 로드 ────────────────────────────────────────────
def load_frame(frame_idx):
    if 0 <= frame_idx < len(frame_files):
        frame = cv2.imread(os.path.join(frame_dir, frame_files[frame_idx]))
        return frame
    return None

current_frame = load_frame(cur_frame_idx)
preview = current_frame.copy()

def mouse_cb(event, x, y, flags, param):
    global preview
    if event == cv2.EVENT_LBUTTONDOWN:      # positive
        click_pts.append([x, y]); click_lbl.append(1)
    elif event == cv2.EVENT_RBUTTONDOWN:    # negative
        click_pts.append([x, y]); click_lbl.append(0)
    # redraw dots
    preview = current_frame.copy()
    for (px, py), lb in zip(click_pts, click_lbl):
        cv2.circle(preview, (px, py), 6,
                   (0, 255, 0) if lb else (0, 0, 255), -1)

cv2.namedWindow('Advanced Interactive Segmentation'); cv2.setMouseCallback('Advanced Interactive Segmentation', mouse_cb)
print('[좌클릭]=fg  [우클릭]=bg  [ENTER]=Seg+Propagate  [←/→]=이동  [n]=새 오브젝트  [r]=리셋  [s]=저장  [l]=불러오기  [q]=quit')

# ───── 프레임 변경 함수 ────────────────────────────────────────────
def change_frame(direction):
    global cur_frame_idx, current_frame, preview, click_pts, click_lbl
    
    # 현재 포인트 저장
    if click_pts:
        if cur_frame_idx not in all_points:
            all_points[cur_frame_idx] = {}
        all_points[cur_frame_idx][cur_obj] = (click_pts.copy(), click_lbl.copy())
    
    # 프레임 변경
    new_idx = cur_frame_idx + direction
    if 0 <= new_idx < len(frame_files):
        cur_frame_idx = new_idx
        current_frame = load_frame(cur_frame_idx)
        
        # 저장된 포인트 불러오기
        click_pts, click_lbl = [], []
        if cur_frame_idx in all_points and cur_obj in all_points[cur_frame_idx]:
            click_pts, click_lbl = all_points[cur_frame_idx][cur_obj]
        
        preview = current_frame.copy()
        for (px, py), lb in zip(click_pts, click_lbl):
            cv2.circle(preview, (px, py), 6,
                       (0, 255, 0) if lb else (0, 0, 255), -1)
        
        print(f"Frame {cur_frame_idx}/{len(frame_files)-1}")

# ───── 배치 처리 함수 ──────────────────────────────────────────────
def process_batch_with_sam2(batch_files, temp_video_path, predictor, all_points, batch_start):
    """배치 단위로 SAM2 세그멘테이션 처리"""
    # 배치용 임시 비디오 생성
    first_frame = cv2.imread(os.path.join(frame_dir, batch_files[0]))
    height, width = first_frame.shape[:2]
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(temp_video_path, fourcc, 30.0, (width, height))
    
    for fname in batch_files:
        frame = cv2.imread(os.path.join(frame_dir, fname))
        out.write(frame)
    out.release()
    
    try:
        # SAM2 상태 초기화
        state = predictor.init_state(
            video_path=temp_video_path,
            offload_video_to_cpu=True
        )
        predictor.reset_state(state)
        
        # 배치 내 모든 포인트 추가
        for frame_idx in sorted(all_points.keys()):
            if batch_start <= frame_idx < batch_start + len(batch_files):
                local_idx = frame_idx - batch_start
                for obj_id in all_points[frame_idx]:
                    points, labels = all_points[frame_idx][obj_id]
                    if points:  # 포인트가 있는 경우만
                        pts = np.array(points, np.float32)
                        lbs = np.array(labels, np.int32)
                        
                        _, _, logits = predictor.add_new_points_or_box(
                            inference_state=state,
                            frame_idx=local_idx,
                            obj_id=obj_id,
                            points=pts,
                            labels=lbs,
                        )
        
        # 배치 내 모든 프레임에 대해 마스크 생성
        video_masks = {}
        for fi, obj_ids, mask_logits in predictor.propagate_in_video(state):
            global_idx = batch_start + fi
            if global_idx not in video_masks:
                video_masks[global_idx] = {}
            for i, oid in enumerate(obj_ids):
                mask = (mask_logits[i] > 0).cpu().numpy().astype(np.float32)
                if mask.ndim == 3:
                    mask = mask[0]  # (1, H, W) -> (H, W)
                video_masks[global_idx][oid] = mask
        
        return video_masks
        
    except Exception as e:
        print(f"Error processing batch: {e}")
        return {}
    finally:
        # 임시 비디오 파일 삭제
        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)

# ───── 인터랙티브 루프 ─────────────────────────────────────────────
while True:
    # 프레임 정보 표시
    info_text = f"Frame: {cur_frame_idx}/{len(frame_files)-1} | Object: {cur_obj} | Points: {len(click_pts)}"
    cv2.putText(preview, info_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    cv2.imshow('Advanced Interactive Segmentation', preview)
    k = cv2.waitKey(10) & 0xFF
    
    if k in (13, 10):                          # ENTER
        if not click_pts and not all_points:
            print("⛔ 먼저 클릭으로 포인트를 지정하세요."); continue
            
        print("세그멘테이션 실행 중...")
        
        # 현재 프레임의 포인트도 저장
        if click_pts:
            if cur_frame_idx not in all_points:
                all_points[cur_frame_idx] = {}
            all_points[cur_frame_idx][cur_obj] = (click_pts.copy(), click_lbl.copy())
        
        # 배치 단위로 처리
        all_masks = {}
        
        for batch_start in range(0, len(frame_files), batch_size):
            batch_end = min(batch_start + batch_size, len(frame_files))
            batch_files = frame_files[batch_start:batch_end]
            
            print(f"Processing batch {batch_start//batch_size + 1}/{(len(frame_files) + batch_size - 1)//batch_size}")
            
            temp_video_path = f"temp_batch_{batch_start}.mp4"
            batch_masks = process_batch_with_sam2(batch_files, temp_video_path, predictor, all_points, batch_start)
            
            # 배치 결과 병합
            all_masks.update(batch_masks)
        
        # 마스크 저장
        os.makedirs(mask_dir, exist_ok=True)
        for fi, m_dict in all_masks.items():
            for oid, mk in m_dict.items():
                mask_img = (mk * 255).astype(np.uint8)
                Image.fromarray(mask_img).save(os.path.join(mask_dir, f"mask_{fi:05d}.png"))
        
        print(f"✓ 마스크 저장 완료 → {mask_dir}")
        
        # 비디오 렌더링
        print("비디오 렌더링 중...")
        from render_video import render_masks_to_video
        render_masks_to_video(frame_dir, mask_dir, output_video, fps)
        
        print(f"✓ 완료! 결과 비디오: {output_video}")
        break
        
    elif k == 81:                              # ← (이전 프레임)
        change_frame(-1)
        
    elif k == 83:                              # → (다음 프레임)
        change_frame(1)
        
    elif k in (ord('n'), ord('N')):            # 새 오브젝트
        cur_obj += 1
        click_pts, click_lbl = [], []
        preview = current_frame.copy()
        print(f"새 오브젝트 ID: {cur_obj}")
        
    elif k in (ord('r'), ord('R')):            # 리셋
        click_pts, click_lbl = [], []
        preview = current_frame.copy()
        print("포인트 초기화됨")
        
    elif k in (ord('s'), ord('S')):            # 저장
        if cur_frame_idx not in all_points:
            all_points[cur_frame_idx] = {}
        all_points[cur_frame_idx][cur_obj] = (click_pts.copy(), click_lbl.copy())
        
        with open('interactive_state.pkl', 'wb') as f:
            pickle.dump(all_points, f)
        print("상태 저장됨")
        
    elif k in (ord('l'), ord('L')):            # 불러오기
        if os.path.exists('interactive_state.pkl'):
            with open('interactive_state.pkl', 'rb') as f:
                all_points = pickle.load(f)
            print("상태 불러옴")
        else:
            print("저장된 상태가 없습니다")
        
    elif k in (ord('q'), 27):                  # quit
        print('종료'); sys.exit(0)

cv2.destroyAllWindows() 