# Qt Wayland 플러그인 오류 해결을 위한 환경 변수 설정
$env:QT_QPA_PLATFORM = "xcb"
$env:DISPLAY = ":0"
$env:QT_DEBUG_PLUGINS = "0"

# Python 스크립트 실행
python video_prediction.py 