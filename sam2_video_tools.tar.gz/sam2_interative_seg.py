#!/usr/bin/env python3
"""
Interactive video-object segmentation with **SAM 2** only
────────────────────────────────────────────────────────────
 ▸ 좌클릭   : positive point  (foreground)
 ▸ 우클릭   : negative point  (background)
 ▸ ENTER    : 현재 프레임을 기준으로 SAM-2 실행 → 전 프레임으로 전파
 ▸ n / N    : 새로운 오브젝트 ID 시작 (멀티-오브젝트 지원)
 ▸ q 또는 ESC: 종료
결과
 └ obj_masks.pkl  : {frame_idx: {obj_id: mask(H,W,float32)}}  (pickle)
 └ 선택적으로 PNG 마스크 ( --mask-dir )
"""

import os, sys, cv2, pickle, argparse, numpy as np, torch
from pathlib import Path

# ───── 필수: sam2 설치 확인 ──────────────────────────────────────────
try:
    from sam2.build_sam import build_sam2_video_predictor
except ModuleNotFoundError:
    sys.exit("❌  sam2가 설치되어 있지 않습니다. `pip install -e sam2` 후 다시 실행하세요.")

# ───── CLI ─────────────────────────────────────────────────────────
ap = argparse.ArgumentParser()
ap.add_argument('--vid',      required=True, help='오브젝트 영상 (mp4/avi …)')
ap.add_argument('--out',      default='obj_masks.pkl', help='pickle 결과 파일')
ap.add_argument('--mask-dir', default='', help='PNG 마스크 저장 폴더 (옵션)')
ap.add_argument('--cfg',      default='configs/sam2.1/sam2.1_hiera_t.yaml',
                help='SAM-2 config (.yaml)')
ap.add_argument('--ckpt',     default='checkpoints/sam2.1_hiera_tiny.pt',
                help='SAM-2 checkpoint (.pt)')
args = ap.parse_args()


DEV = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f'device: {DEV}  |  SAM-2 cfg: {Path(args.cfg).name}')

# ───── SAM-2 Predictor 로드 ───────────────────────────────────────
predictor = build_sam2_video_predictor(
    args.cfg, args.ckpt, device=DEV
)

# ───── 비디오 정보만 로드 (메모리 절약) ─────────────────────
cap = cv2.VideoCapture(args.vid)
assert cap.isOpened(), f'cannot open {args.vid}'
total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
cap.release()
print(f'frames: {total_frames}  |  size: {W}×{H}')

# 메모리 부족 방지를 위해 첫 프레임만 로드
cap = cv2.VideoCapture(args.vid)
ret, first_frame = cap.read()
cap.release()
if not ret:
    sys.exit("❌ 첫 프레임을 읽을 수 없습니다.")

# ───── 마우스 인터랙션 설정 ────────────────────────────────────────
click_pts, click_lbl = [], []           # [[x,y]], [label]
cur_obj = 1
ann_f   = 0                             # annotating this frame
preview = first_frame.copy()

def mouse_cb(event, x, y, flags, param):
    global preview
    if event == cv2.EVENT_LBUTTONDOWN:      # positive
        click_pts.append([x, y]); click_lbl.append(1)
    elif event == cv2.EVENT_RBUTTONDOWN:    # negative
        click_pts.append([x, y]); click_lbl.append(0)
    # redraw dots
    preview = first_frame.copy()
    for (px, py), lb in zip(click_pts, click_lbl):
        cv2.circle(preview, (px, py), 6,
                   (0, 255, 0) if lb else (0, 0, 255), -1)

cv2.namedWindow('click'); cv2.setMouseCallback('click', mouse_cb)
print('[좌클릭]=fg  [우클릭]=bg  [ENTER]=Seg+Propagate  [n]=새 오브젝트  [q]=quit')

while True:
    cv2.imshow('click', preview)
    k = cv2.waitKey(10) & 0xFF
    if k in (13, 10):                          # ENTER
        if not click_pts:
            print("⛔ 먼저 클릭으로 포인트를 지정하세요."); continue
        # SAM-2 상태 초기화
        state = predictor.init_state(
            video_path=args.vid,
            offload_video_to_cpu=True
        )
        predictor.reset_state(state)
        pts = np.array(click_pts, np.float32)
        lbs = np.array(click_lbl, np.int32)
        _, _, logits = predictor.add_new_points_or_box(
            inference_state=state,
            frame_idx=ann_f,
            obj_id=cur_obj,
            points=pts,
            labels=lbs,
        )
        # 첫 프레임 마스크 확인용 (선택)
        m0 = (logits[0] > 0).cpu().numpy().astype(np.float32)
        # 마스크가 올바른 형태인지 확인하고 표시
        if m0.ndim == 2:
            mask_display = (m0 * 255).astype(np.uint8)
            cv2.imshow('mask preview', mask_display)
            cv2.waitKey(500)
        else:
            print(f"Warning: Unexpected mask shape: {m0.shape}")

        # 전체 프레임 전파
        video_masks = {}
        for fi, obj_ids, mask_logits in predictor.propagate_in_video(state):
            if fi not in video_masks:
                video_masks[fi] = {}
            for i, oid in enumerate(obj_ids):
                video_masks[fi][oid] = (mask_logits[i] > 0).cpu().numpy().astype(np.float32)
        break

    elif k in (ord('n'), ord('N')):            # 새 오브젝트
        cur_obj += 1
        click_pts, click_lbl = [], []
        preview = first_frame.copy()
    elif k in (ord('q'), 27):                  # quit
        print('abort'); sys.exit(0)

cv2.destroyAllWindows()

# ───── 결과 저장 ──────────────────────────────────────────────────
with open(args.out, 'wb') as f:
    pickle.dump(video_masks, f)
print(f'✓ masks saved → {args.out}')

# PNG 저장 (옵션)
if args.mask_dir:
    mdir = Path(args.mask_dir); mdir.mkdir(parents=True, exist_ok=True)
    for fi, m_dict in video_masks.items():
        for oid, mk in m_dict.items():
            cv2.imwrite(str(mdir / f'{fi:05d}_{oid}.png'),
                        (mk * 255).astype(np.uint8))
    print(f'PNG masks → {mdir}')
