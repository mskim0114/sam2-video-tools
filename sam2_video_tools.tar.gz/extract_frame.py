import cv2
import os

def extract_frames(video_path, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    cap = cv2.VideoCapture(video_path)
    idx = 0
    success, frame = cap.read()
    while success:
        frame_path = os.path.join(output_dir, f'frame_{idx:05d}.jpg')
        cv2.imwrite(frame_path, frame)
        idx += 1
        success, frame = cap.read()
    cap.release()
    print(f"Extracted {idx} frames to {output_dir}")
    return idx
