#!/usr/bin/env python3

from sam2.build_sam import build_sam2_video_predictor

# Predictor 생성
predictor = build_sam2_video_predictor(
    'configs/sam2.1/sam2.1_hiera_t.yaml', 
    'checkpoints/sam2.1_hiera_tiny.pt'
)

print("Available methods:")
for method in dir(predictor):
    if not method.startswith('_'):
        print(f"  {method}")

print("\nPredictor type:", type(predictor)) 