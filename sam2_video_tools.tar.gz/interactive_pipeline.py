#!/usr/bin/env python3
"""
Interactive Video Segmentation Pipeline with SAM2 (Memory Optimized)
────────────────────────────────────────────────────────────
 ▸ 좌클릭   : positive point  (foreground)
 ▸ 우클릭   : negative point  (background)
 ▸ ENTER    : 현재 프레임을 기준으로 SAM-2 실행 → 전체 비디오로 전파
 ▸ n / N    : 새로운 오브젝트 ID 시작 (멀티-오브젝트 지원)
 ▸ r / R    : 현재 프레임의 포인트 초기화
 ▸ q 또는 ESC: 종료
결과
 └ segmentation_result.mp4  : 최종 세그멘테이션 비디오
 └ output_masks/           : PNG 마스크 파일들
"""

import os, sys, cv2, numpy as np, torch
from pathlib import Path
from PIL import Image

# ───── 필수: sam2 설치 확인 ──────────────────────────────────────────
try:
    from sam2.build_sam import build_sam2_video_predictor
except ModuleNotFoundError:
    sys.exit("❌  sam2가 설치되어 있지 않습니다. `pip install -e sam2` 후 다시 실행하세요.")

# ───── 설정값 ─────────────────────────────────────────────────────────
video_path = '도로주행2.mp4'
frame_dir = 'tmp_frames'
mask_dir = 'output_masks'
output_video = 'segmentation_result.mp4'
sam2_checkpoint = "checkpoints/sam2.1_hiera_tiny.pt"
model_cfg = "configs/sam2.1/sam2.1_hiera_t.yaml"
fps = 30
batch_size = 100  # 메모리 절약을 위한 배치 크기

# ───── 프레임 추출 (이미 있다면 건너뛰기) ───────────────────────────
if not os.path.exists(frame_dir) or len(os.listdir(frame_dir)) == 0:
    print("프레임 추출 중...")
    from extract_frame import extract_frames
    extract_frames(video_path, frame_dir)
else:
    print("기존 프레임 사용")

# ───── 비디오 정보 로드 ─────────────────────────────────────────────
cap = cv2.VideoCapture(video_path)
assert cap.isOpened(), f'cannot open {video_path}'
total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
cap.release()
print(f'frames: {total_frames}  |  size: {W}×{H}')

# ───── SAM-2 Predictor 로드 ───────────────────────────────────────
DEV = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f'device: {DEV}  |  SAM-2 cfg: {Path(model_cfg).name}')

predictor = build_sam2_video_predictor(model_cfg, sam2_checkpoint, device=DEV)

# ───── 마우스 인터랙션 설정 ────────────────────────────────────────
click_pts, click_lbl = [], []           # [[x,y]], [label]
cur_obj = 1
ann_f   = 0                             # annotating this frame

# 첫 프레임 로드
frame_files = sorted([f for f in os.listdir(frame_dir) if f.lower().endswith('.jpg')])
first_frame = cv2.imread(os.path.join(frame_dir, frame_files[0]))
preview = first_frame.copy()

def mouse_cb(event, x, y, flags, param):
    global preview
    if event == cv2.EVENT_LBUTTONDOWN:      # positive
        click_pts.append([x, y]); click_lbl.append(1)
    elif event == cv2.EVENT_RBUTTONDOWN:    # negative
        click_pts.append([x, y]); click_lbl.append(0)
    # redraw dots
    preview = first_frame.copy()
    for (px, py), lb in zip(click_pts, click_lbl):
        cv2.circle(preview, (px, py), 6,
                   (0, 255, 0) if lb else (0, 0, 255), -1)

cv2.namedWindow('Interactive Segmentation'); cv2.setMouseCallback('Interactive Segmentation', mouse_cb)
print('[좌클릭]=fg  [우클릭]=bg  [ENTER]=Seg+Propagate  [n]=새 오브젝트  [r]=리셋  [q]=quit')

# ───── 배치 처리 함수 ──────────────────────────────────────────────
def process_batch_with_sam2(batch_files, temp_video_path, predictor, click_pts, click_lbl, cur_obj):
    """배치 단위로 SAM2 세그멘테이션 처리"""
    # 배치용 임시 비디오 생성
    first_frame = cv2.imread(os.path.join(frame_dir, batch_files[0]))
    height, width = first_frame.shape[:2]
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(temp_video_path, fourcc, 30.0, (width, height))
    
    for fname in batch_files:
        frame = cv2.imread(os.path.join(frame_dir, fname))
        out.write(frame)
    out.release()
    
    try:
        # SAM2 상태 초기화
        state = predictor.init_state(
            video_path=temp_video_path,
            offload_video_to_cpu=True
        )
        predictor.reset_state(state)
        
        # 첫 프레임에서 포인트 추가
        if click_pts:
            pts = np.array(click_pts, np.float32)
            lbs = np.array(click_lbl, np.int32)
            
            _, _, logits = predictor.add_new_points_or_box(
                inference_state=state,
                frame_idx=0,  # 배치 내 첫 프레임
                obj_id=cur_obj,
                points=pts,
                labels=lbs,
            )
        
        # 배치 내 모든 프레임에 대해 마스크 생성
        video_masks = {}
        for fi, obj_ids, mask_logits in predictor.propagate_in_video(state):
            if fi not in video_masks:
                video_masks[fi] = {}
            for i, oid in enumerate(obj_ids):
                mask = (mask_logits[i] > 0).cpu().numpy().astype(np.float32)
                if mask.ndim == 3:
                    mask = mask[0]  # (1, H, W) -> (H, W)
                video_masks[fi][oid] = mask
        
        return video_masks
        
    except Exception as e:
        print(f"Error processing batch: {e}")
        return {}
    finally:
        # 임시 비디오 파일 삭제
        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)

# ───── 인터랙티브 루프 ─────────────────────────────────────────────
while True:
    cv2.imshow('Interactive Segmentation', preview)
    k = cv2.waitKey(10) & 0xFF
    
    if k in (13, 10):                          # ENTER
        if not click_pts:
            print("⛔ 먼저 클릭으로 포인트를 지정하세요."); continue
            
        print("세그멘테이션 실행 중...")
        
        # 배치 단위로 처리
        all_masks = {}
        
        for batch_start in range(0, len(frame_files), batch_size):
            batch_end = min(batch_start + batch_size, len(frame_files))
            batch_files = frame_files[batch_start:batch_end]
            
            print(f"Processing batch {batch_start//batch_size + 1}/{(len(frame_files) + batch_size - 1)//batch_size}")
            
            temp_video_path = f"temp_batch_{batch_start}.mp4"
            batch_masks = process_batch_with_sam2(batch_files, temp_video_path, predictor, click_pts, click_lbl, cur_obj)
            
            # 배치 결과를 전체 인덱스로 변환
            for local_idx, masks in batch_masks.items():
                global_idx = batch_start + local_idx
                all_masks[global_idx] = masks
        
        # 마스크 저장
        os.makedirs(mask_dir, exist_ok=True)
        for fi, m_dict in all_masks.items():
            for oid, mk in m_dict.items():
                mask_img = (mk * 255).astype(np.uint8)
                Image.fromarray(mask_img).save(os.path.join(mask_dir, f"mask_{fi:05d}.png"))
        
        print(f"✓ 마스크 저장 완료 → {mask_dir}")
        
        # 비디오 렌더링
        print("비디오 렌더링 중...")
        from render_video import render_masks_to_video
        render_masks_to_video(frame_dir, mask_dir, output_video, fps)
        
        print(f"✓ 완료! 결과 비디오: {output_video}")
        break
        
    elif k in (ord('n'), ord('N')):            # 새 오브젝트
        cur_obj += 1
        click_pts, click_lbl = [], []
        preview = first_frame.copy()
        print(f"새 오브젝트 ID: {cur_obj}")
        
    elif k in (ord('r'), ord('R')):            # 리셋
        click_pts, click_lbl = [], []
        preview = first_frame.copy()
        print("포인트 초기화됨")
        
    elif k in (ord('q'), 27):                  # quit
        print('종료'); sys.exit(0)

cv2.destroyAllWindows() 