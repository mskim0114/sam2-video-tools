#!/usr/bin/env python3

import os
import numpy as np
from PIL import Image
import torch
import cv2

from sam2.build_sam import build_sam2_video_predictor

def test_small_batch():
    frame_dir = 'tmp_frames'
    mask_dir = 'test_masks'
    sam2_checkpoint = "checkpoints/sam2.1_hiera_tiny.pt"
    model_cfg = "configs/sam2.1/sam2.1_hiera_t.yaml"
    
    os.makedirs(mask_dir, exist_ok=True)
    frame_files = sorted([f for f in os.listdir(frame_dir) if f.lower().endswith('.jpg')])
    
    # 첫 5개 프레임만 테스트
    test_files = frame_files[:5]
    print(f"Testing with {len(test_files)} frames")
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    predictor = build_sam2_video_predictor(model_cfg, sam2_checkpoint, device=device)
    
    # 임시 비디오 생성
    temp_video_path = "test_temp.mp4"
    
    first_frame = cv2.imread(os.path.join(frame_dir, test_files[0]))
    height, width = first_frame.shape[:2]
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(temp_video_path, fourcc, 30.0, (width, height))
    
    for fname in test_files:
        frame = cv2.imread(os.path.join(frame_dir, fname))
        out.write(frame)
    out.release()
    
    try:
        state = predictor.init_state(
            video_path=temp_video_path,
            offload_video_to_cpu=True
        )
        predictor.reset_state(state)
        
        for idx, fname in enumerate(test_files):
            center_x, center_y = width // 2, height // 2
            points = np.array([[center_x, center_y]], dtype=np.float32)
            labels = np.array([1], dtype=np.int32)
            
            _, _, logits = predictor.add_new_points_or_box(
                inference_state=state,
                frame_idx=idx,
                obj_id=1,
                points=points,
                labels=labels,
                box=None
            )
            
            mask_pred = (logits[0] > 0).cpu().numpy().astype(np.float32)
            print(f"Mask shape: {mask_pred.shape}, dtype: {mask_pred.dtype}")
            
            if mask_pred.ndim == 3:
                if mask_pred.shape[0] == 1:
                    mask_pred = mask_pred[0]
                else:
                    mask_pred = mask_pred.squeeze()
            
            mask_img = (mask_pred * 255).astype(np.uint8)
            Image.fromarray(mask_img).save(os.path.join(mask_dir, f"test_mask_{idx:05d}.png"))
            print(f"Saved test_mask_{idx:05d}.png")
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)

if __name__ == "__main__":
    test_small_batch() 